<template>
  <div>
   <div class="list" >
      <van-checkbox-group v-model="result" ref="checkboxGroup">
        <div  class="list-item" v-for="item in list" :key="item.id">
            <router-link to="/position/123" class="tit" >
                <p class="name"><span>{{item.work_name}}</span></p>
                <p class="pay"><span>{{item.month_pay}}</span></p>
            </router-link>
            <div class="need">
                <p>
                    <span>{{item.type}}</span>|
                    <span>{{item.edu}}</span>
                </p>
                <em class="area">{{item.area}}</em>
            </div>
            <div class="opa">
                <p class="company">{{item.company}}</p>
                <button class="dele" @click="dele(item._id)">删除</button>
            </div>
        </div>
        </van-checkbox-group>
    </div>
    <div class="no" v-show="text">
        暂无申请记录
    </div>
  </div>
</template>

<script>
import axios from "axios";
import { Toast } from "vant";
export default {
  data() {
    return {
      result: [],
      list: [],
      text:true
    };
  },
  methods: {
    dele(id) {
      this.$axios.post("/api/app/apply_delete",{
        phone: localStorage.getItem("info"),
        _ids: id
      }).then(res=>{
        if(res.data.code==0){
          Toast("删除成功");
        }else{
          Toast("删除失败");
        }
      })
    }
  },
  created() {
    this.$axios
      .get("/api/app/apply_all?phone="+localStorage.getItem("info"))
      .then(res => {
        console.log(res)
          this.list=(res.data.data)
        for (var i of this.list) {
        this.result.push(i._id);
        if(res.data.data!==[]){
          this.text=false
        }
      }
      });
      
  }
}
</script>

<style lang="scss" scoped>
.list {
  width: 100%;
  background-color: #fff;
  margin-bottom: 52px;
  .list-item {
    position: relative;
    margin: 0 16px 0 16px;
    padding: 14px 0 14px 0;
    border-top: 1px solid #f0f0f0;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    line-height: 20px;
    .choice {
      position: absolute;
      left: 0;
      input {
        width: 20px;
        height: 20px;
      }
    }
    .tit {
      width: 100%;
      font-weight: 700;
      font-size: 16px;
      color: #222;
      display: flex;
      justify-content: space-between;
      .name {
        width: 60%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .pay {
        font-weight: 700;
        font-size: 14px;
        color: #ff7e3e;
        width: 26%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        span {
          float: right;
        }
      }
    }
    .need {
      width: 100%;
      margin: 8px 0;
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #666;
      p > span {
        padding-right: 4px;
      }
    }
    .opa {
      width: 100%;
      display: flex;
      justify-content: space-between;
      line-height: 30px;
      font-size: 14px;
      .company {
        color: #222;
      }
      .dele {
        width: 70px;
        height: 30px;
        border: none;
        color: #ff7e3e;
        font-size: 14px;
        font-weight: 700;
        background-color: #ffe8dc;
        border-radius: 30px;
      }
    }
  }
  .list-item:first-child {
    border-top: none;
  }
  .more {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 48px;
    margin: 0 16px;
    border-top: 1px solid #f0f0f0;
    font-size: 14px;
    color: #666;
    span {
      font-size: 12px;
      padding-left: 5px;
      color: #ccc;
    }
  }
}
.no{
  text-align: center;
  height: 500px;
  line-height: 400px
}
</style>